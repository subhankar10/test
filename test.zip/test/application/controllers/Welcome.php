<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

  public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->library('session');
         $this->load->helper('url');
         $this->load->library('email');
        
        
    }
	public function index()
	{
		$this->load->model('Model');
		$qry = "CALL list_view()";
		$data['view']=$this->Model->jSONservices($qry);
		print_r($data['view']);
		$this->load->view('welcome_message');
	}
}
