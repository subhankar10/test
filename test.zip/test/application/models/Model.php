<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model extends CI_Model{

public function jSONservices($qry)
{
	$rs=$this->db->query($qry);
	if ($rs->num_rows() > 0){
	$results=$rs->result_array();
	$rs->next_result();
	$rs->free_result();
	return $results;
	}
	else{
	$rs->next_result();
	$rs->free_result();
	return ;
     
	}
}
}
?>